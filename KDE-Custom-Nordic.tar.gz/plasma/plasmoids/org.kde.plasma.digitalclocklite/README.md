# Digital Clock Lite KDE Applet
org.kde.plasma.digitalclocklite

Fork from org.kde.plasma.digitalclock, with a feature to choose the size of the clock
