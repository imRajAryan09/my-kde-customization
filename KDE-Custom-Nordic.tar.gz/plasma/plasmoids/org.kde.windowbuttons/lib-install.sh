#! /bin/bash
cp -r .local/share/plasma/plasmoids/org.kde.windowbuttons/lib/  /usr/lib/qt/qml/org/kde/appletdecoration/
echo Installed libraries for Window Buttons Applet!
