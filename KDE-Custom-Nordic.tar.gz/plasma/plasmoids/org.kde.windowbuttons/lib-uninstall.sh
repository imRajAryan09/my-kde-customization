 #! /bin/bash
rm -rf /usr/lib/qt/qml/org/kde/appletdecoration/
echo Uninstalled libraries for Window Buttons Applet!
