### CHANGELOG

#### Version 0.1.1

* fix startup warning

#### Version 0.1

* option for thickness margins
* option for length margins
