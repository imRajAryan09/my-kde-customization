applet.currentConfigGroup = new Array("General");
applet.writeConfig("alphaSort","true");
applet.writeConfig("limitDepth","true");
applet.reloadConfig();