applet.currentConfigGroup = new Array("General");
applet.writeConfig("showSecondHand", true);
applet.reloadConfig();