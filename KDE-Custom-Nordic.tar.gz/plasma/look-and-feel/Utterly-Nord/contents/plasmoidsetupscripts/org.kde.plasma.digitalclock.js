applet.currentConfigGroup = new Array("Appearance");
applet.writeConfig("customDateFormat","ddd d MMM");
applet.writeConfig("dateDisplayFormat","BesideTime");
applet.writeConfig("dateFormat","custom");
applet.writeConfig("enabledCalendarPlugins","/usr/lib/qt/plugins/plasmacalendarplugins/astronomicalevents.so,/usr/lib/qt/plugins/plasmacalendarplugins/holidaysevents.so");
applet.writeConfig("firstDayOfWeek","0");
applet.writeConfig("showWeekNumbers","true");
applet.writeConfig("use24hFormat","0");
applet.reloadConfig();