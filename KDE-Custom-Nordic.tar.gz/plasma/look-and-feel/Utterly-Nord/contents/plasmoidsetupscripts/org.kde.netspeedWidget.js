applet.currentConfigGroup = new Array("General");
applet.writeConfig("swapDownUp","true");
applet.reloadConfig();