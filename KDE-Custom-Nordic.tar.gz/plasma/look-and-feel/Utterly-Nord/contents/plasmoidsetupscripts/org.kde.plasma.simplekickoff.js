applet.currentConfigGroup = new Array("Shortcuts");
applet.writeConfig("global","Alt+F1");
applet.currentConfigGroup = new Array("General");
applet.writeConfig("alphaSort","true");
applet.reloadConfig();